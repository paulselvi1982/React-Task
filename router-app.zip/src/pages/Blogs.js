import React from 'react';
 
const Blogs = () => {
    return (
        <h1>Please write your blogs!</h1>
    );
};
 
export default Blogs;