import React from 'react';
 
const Contact = () => {
    return (
        <div>
            <h1>contact me at paulselvi1982@gmail.com</h1>
        </div>
    );
};
 
export default Contact;