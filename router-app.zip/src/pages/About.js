import React from "react";
 
const About = () => {
    return (
        <div>
            <h1>
                Hello World!!!
            </h1>
        </div>
    );
};
 
export default About;