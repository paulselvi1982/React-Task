import Adduser from "./components/Adduser";
import Errorhandling from "./components/Errorhandling";
import Deleteuser from "./components/Deleteuser";
import Updateuser from "./components/Updateuser";
import Users from "./components/Users";

function App() {
  return (
    <div>
      <h1>List of users</h1>
      <Users /><br/><br/>

      <h1>Add users</h1>
      <Adduser /><br/><br/>

      <h1>Update users</h1>
      <Updateuser /><br/><br/>

      <h1>Delete users</h1>
      <Deleteuser /><br/><br/>

      <h1>Error Handling</h1>
      <Errorhandling /><br/><br/>
    </div>
  );
}

export default App;